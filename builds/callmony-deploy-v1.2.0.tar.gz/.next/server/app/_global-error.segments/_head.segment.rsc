1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/901ba5c36def3998.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/901ba5c36def3998.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"SAPESWKJV5_9xeRnmDUdR","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[]}]}]}],null]}],"loading":null,"isPartial":false}
