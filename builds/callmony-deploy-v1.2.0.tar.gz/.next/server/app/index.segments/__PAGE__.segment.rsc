1:"$Sreact.fragment"
2:I[71250,["/_next/static/chunks/ecbb64dc112ad516.js","/_next/static/chunks/c927ce7d630f864d.js","/_next/static/chunks/725cd7f8d5568065.js"],"CallmonyApp"]
3:I[97367,["/_next/static/chunks/901ba5c36def3998.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"SAPESWKJV5_9xeRnmDUdR","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/c927ce7d630f864d.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/725cd7f8d5568065.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
